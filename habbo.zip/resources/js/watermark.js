var watermarkindex = randint(1,3);

var img = document.createElement('img');
img.src = './icons/' + watermarkindex + '.png';
document.body.appendChild(img)