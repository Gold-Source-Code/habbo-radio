<img class="dorito" src="{{asset('icons/dorito-spin.gif')}}" alt="dorito"></img>
