
    <?php $__env->startPush('style'); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/interrogation.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('main'); ?>
        <div class="center">
            <form action="/songform/store" method="POST">
                <?php echo csrf_field(); ?>
                <label class="question" for="name">Name:</label><br>
                <input type="text" id="name" name="name" value=""><br>
                <?php $__errorArgs = ["name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="errormessage"><?php echo e($message); ?> Fix it.</div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label class="question" for="artist">Artist:</label><br>
                <input type="text" id="artist" name="artist" value=""><br>
                <?php $__errorArgs = ["artist"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="errormessage"><?php echo e($message); ?> Fix it.</div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label class="question" for="duration">Duration:</label><br>
                <input type="text" id="duration" name="duration" value=""><br>
                <?php $__errorArgs = ["duration"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="errormessage"><?php echo e($message); ?> Fix it.</div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <label class="question" for="genre_id">Genre:</label><br>
                <input type="text" id="genre_id" name="genre_id" value=""><br>
                <?php $__errorArgs = ["genre_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="errormessage"><?php echo e($message); ?> Fix it.</div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <input class="answer" type="submit" value="Send">
            </form>
        </div>

        <br>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.gecklayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\habbo-radio\resources\views/songform.blade.php ENDPATH**/ ?>