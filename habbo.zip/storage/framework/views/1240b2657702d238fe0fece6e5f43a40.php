
    <?php $__env->startPush('style'); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/playlistdetail.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('main'); ?>
        <?php
            $playlist_dur = 0;
            foreach ($songs as $song){
                $playlist_dur = $playlist_dur + $song->duration;
                }
            
            $total_runtime = $playlist_dur;
                
            $min = intval($total_runtime / 60);
            $sec = sprintf("%02d", $total_runtime % 60);

            $dur = "$min:$sec";
            ?>

        <div class="PlaylistName">Temporary Playlist - <?php echo e($dur); ?></div>
        <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('song_detail', ['song' => $song->id])); ?>">
                    <input type="button" class="SongText" id="click" value="<?php echo e($song->name); ?>">
                </a>
                <a href="<?php echo e(route('removetemp', ['song' => $song->id])); ?>">
                    <input type="button" class="SongText" id="click" value=" - ">
                </a>
                <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.habbolayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\habbo-radio\resources\views/tempplaylistdetail.blade.php ENDPATH**/ ?>