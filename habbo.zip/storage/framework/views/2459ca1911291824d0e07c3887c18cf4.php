
    <?php $__env->startPush('style'); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/interrogation.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('main'); ?>
        <div class="center">
            <form action="/addsongs/add" method="POST">
                <?php echo csrf_field(); ?>
                <select name="playlist_id" multiple>
                    <?php $__currentLoopData = $playlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $playlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option class="options" value="<?php echo e($playlist->id); ?>" for="playlist_id"><?php echo e($playlist->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><br>
                <?php $__errorArgs = ["playlist_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="errormessage"><?php echo e($message); ?> Fix it.</div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <select name="song_id" multiple>
                    <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option class="options" value="<?php echo e($song->id); ?>" for="song_id"><?php echo e($song->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><br>
                <?php $__errorArgs = ["song_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="errormessage"><?php echo e($message); ?> Fix it.</div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                <input class="answer" type="submit" value="Send">
            </form>
        </div>

        <br>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('transmit'); ?>
        <a href="<?php echo e(route('transmit', ['playlist' => $playlist->id])); ?>">  
            <button>Transmit</button>
        </a>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.gecklayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\habbo-radio\resources\views/addsongs.blade.php ENDPATH**/ ?>