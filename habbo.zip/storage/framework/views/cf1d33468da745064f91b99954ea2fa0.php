
    <?php $__env->startPush('style'); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/geck.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('main'); ?>
        <div class="center">
            <a href="/genreform">
                <input type="button" class="buttons" id="click" value="Submit Genre">
            </a>
            <a href="/songform">
                <input type="button" class="buttons" id="click" value="Submit Song">
            </a>
            <a href="/playlistform">
                <input type="button" class="buttons" id="click" value="Submit Playlist">
            </a>
            <a href="/addsongs">
                <input type="button" class="buttons" id="click" value="Add Song To Playlist">
            </a>
            <a href="/selectplaylist">
                <input type="button" class="buttons" id="click" value="Remove Song From Playlist">
            </a>
        </div>

        <br>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.gecklayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\habbo-radio\resources\views/geck.blade.php ENDPATH**/ ?>