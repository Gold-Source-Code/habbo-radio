<!DOCTYPE html>
<html>
    <head>
        <title>Habbo Radio</title>
        <?php echo $__env->yieldPushContent('style'); ?>
    <head\>
    <body>
        <img class="logo" src="<?php echo e(asset('icons/habbo.png')); ?>" alt="logo">

        <?php echo $__env->yieldContent('main'); ?>

        <div class="center">
            <a href="/melon">
                <button>Songs</button>
            </a>

            <a href="/genre">
                <button>Genres</button>
            </a>

            <a href="/playlist">
                <button>Playlists</button>
            </a>

            <a href="/geck">
                <button>G.E.C.K.</button>
            </a>

            <a href="/tempplaylistdetail">
                <button>Package</button>
            </a>
        </div>
            
        <div class="watermark">
            <img src="<?php echo e(asset('icons/cooler.gif')); ?>" alt="watermark">
        </div>
    <body\>
<html\><?php /**PATH C:\xampp\htdocs\habbo-radio\resources\views/layouts/habbolayout.blade.php ENDPATH**/ ?>