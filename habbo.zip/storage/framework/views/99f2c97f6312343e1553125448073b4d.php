<!DOCTYPE html>
<html>
    <head>
        <title>Habbo Radio</title>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/interrogation.css')); ?>">
    </head>
    <body>
        <img class="geck" src="<?php echo e(asset('icons/geck.png')); ?>" alt="geck">
        <div class= "Title">Garden of Eden Creation Kit</div>

        <br>

        <div class="center">
            <form action="/removesong/<?php echo e($playlist->id); ?>/remove" method="POST">
                <?php echo csrf_field(); ?>


                <select name="song_id" multiple>
                    <?php $__currentLoopData = $playlist -> songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option class="options" value="<?php echo e($song->id); ?>" for="song_id"><?php echo e($song->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select><br>
                <?php $__errorArgs = ["song_id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="errormessage"><?php echo e($message); ?> Fix it.</div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                <input class="answer" type="submit" value="Send">
            </form>
        </div>

        <br>

        <div class="center">
            <a href="/melon">
            <button>Songs</button>
            </a>

            <a href="/genre">
            <button>Genres</button>
            </a>

            <a href="/playlist">
            <button>Playlists</button>
            </a>

            <a href="/geck">
            <button>G.E.C.K.</button>
            </a>
        </div>

        <div class="watermark">
            <img src="<?php echo e(asset('icons/3.png')); ?>" alt="watermark">
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\habbo-radio\resources\views/removesong.blade.php ENDPATH**/ ?>