<!DOCTYPE html>
<html>
    <head>
        <title>Habbo Radio</title>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/playlistdetail.css')); ?>">
    </head>
    <body>
        <img class="logo" src="<?php echo e(asset('icons/habbo.png')); ?>" alt="logo">
        
        <?php
            $playlist_dur = 0;
            foreach ($playlist -> songs as $song){
                $playlist_dur = $playlist_dur + $song->duration;
                }
            
            $total_runtime = $playlist_dur;
                
            $min = intval($total_runtime / 60);
            $sec = sprintf("%02d", $total_runtime % 60);

            $dur = "$min:$sec";
            ?>

        <div class="PlaylistName"><?php echo e($playlist->name); ?> - <?php echo e($dur); ?></div>
        <?php $__currentLoopData = $playlist -> songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('song_detail', ['song' => $song->id])); ?>">
                <input type="button" class="SongText" id="click" value="<?php echo e($song->name); ?>">
                <br>
                </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        
        <div class="center">
            <a href="/melon">
            <button>Songs</button>
            </a>
            
            <a href="/genre">
            <button>Genres</button>
            </a>

            <a href="/playlist">
            <button>Playlists</button>
            </a>

            <a href="/geck">
            <button>G.E.C.K.</button>
            </a>
        </div>
            
        <div class="watermark">
            <img src="<?php echo e(asset('icons/3.png')); ?>" alt="watermark">
        </div>
    </body>
</html><?php /**PATH C:\xampp\htdocs\habbo-radio\resources\views/playlistdetail.blade.php ENDPATH**/ ?>