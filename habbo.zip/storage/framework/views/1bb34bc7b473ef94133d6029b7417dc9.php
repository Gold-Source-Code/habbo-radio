
    <?php $__env->startPush('style'); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/songdetail.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('main'); ?>
        <div class="SongName"><?php echo e($song->name); ?></div>

        <?php
                $total_runtime = $song->duration;
                
                $min = intval($total_runtime / 60);
                $sec = sprintf("%02d", $total_runtime % 60);

                $dur = "$min:$sec";
                ?>

        <div class="SongText"><?php echo e($song->artist); ?> - <?php echo e($dur); ?> - <?php echo e($song->genre->type); ?></div>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.habbolayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\habbo-radio\resources\views/songdetail.blade.php ENDPATH**/ ?>