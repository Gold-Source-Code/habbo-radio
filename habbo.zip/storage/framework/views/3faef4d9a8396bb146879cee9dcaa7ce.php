
    <?php $__env->startPush('style'); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/melon.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('main'); ?>
        <?php $__currentLoopData = $songs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $song): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('song_detail', ['song' => $song->id])); ?>">
                    <input type="button" class="SongText" id="click" value="<?php echo e($song->name); ?>">
                </a>
                <a href="<?php echo e(route('storetemp', ['song' => $song->id])); ?>">
                    <input type="button" class="SongText" id="click" value=" + ">
                </a>
            <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.habbolayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\habbo-radio\resources\views/melon.blade.php ENDPATH**/ ?>