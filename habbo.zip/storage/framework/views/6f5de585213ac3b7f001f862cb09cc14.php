
    <?php $__env->startPush('style'); ?>
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/genre.css')); ?>">
    <?php $__env->stopPush(); ?>
    <?php $__env->startSection('main'); ?>
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route('selectgenre', ['genre' => $genre->id])); ?>">
                    <input type="button" class="GenreText" id="click" value="<?php echo e($genre->type); ?>">
                </a>
                <br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.habbolayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\habbo-radio\resources\views/genre.blade.php ENDPATH**/ ?>